using System.Linq.Expressions;
using Microsoft.Extensions.Logging;
using BibliotecaMultimedia.Domain.Models;
using BibliotecaMultimedia.Domain.Constants;
using BibliotecaMultimedia.Domain.Interfaces;
using BibliotecaMultimedia.Application.Mappers;
using BibliotecaMultimedia.Domain.Exceptions;
using BibliotecaMultimedia.Application.Interfaces;
using BibliotecaMultimedia.Application.DTOs.Eventos;
using BibliotecaMultimedia.Application.DTOs.Peticion.Items;
using BibliotecaMultimedia.Application.DTOs.Respuesta.Items;
using BibliotecaMultimedia.Application.DTOs.Respuesta.Paginacion;
using BibliotecaMultimedia.Application.DTOs.Peticion.Paginacion.Filtros;


namespace BibliotecaMultimedia.Application.Service;

public class ItemService : IItemService
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<ItemService> _logger;
    private readonly IServiceBus _serviceBus;

    public ItemService(IUnitOfWork unitOfWork, ILogger<ItemService> logger, IServiceBus serviceBus)
    {
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _serviceBus = serviceBus ?? throw new ArgumentNullException(nameof(serviceBus));
    }

    public async Task<RespuestaPaginada<RespuestaItemDto>> ObtenerItemsPaginado(FiltroItem filtroItem, CancellationToken cancellationToken = default)
    {
        Expression<Func<Item, bool>>? filtro = null;

        if (!string.IsNullOrWhiteSpace(filtroItem.TerminoBusqueda))
        {
            string terminoBusqueda = filtroItem.TerminoBusqueda.ToLower();
            filtro = i => i.Title.ToLower().Contains(terminoBusqueda.ToLower());
        }

        (IEnumerable<ItemMapper.ProyeccionItemDto> registros, int total) = await _unitOfWork.Items.ObtenerPaginadosProyectadosAsync(
            selector: ItemMapper.ProyeccionLista(),
            filter: filtro,
            pageNumber: filtroItem.PageNumber,
            pageSize: filtroItem.PageSize,
            ordenarPor: filtroItem.OrdenarPor,
            ordenDescendente: filtroItem.OrdenDescendente,
            cancellationToken: cancellationToken);
        
        int totalPaginas = (int)Math.Ceiling(total / (double)filtroItem.PageSize);
        
        RespuestaPaginada<RespuestaItemDto> respuesta = registros
            .MapProyeccionToDto()
            .ToRespuestaPaginada(total, totalPaginas, filtroItem.PageNumber, filtroItem.PageSize);
        
        _logger.LogInformation("Items paginados: Página {Page} de {TotalPages} con {Count} registros", 
            respuesta.Metadata.PaginaActual, respuesta.Metadata.TotalPaginas, respuesta.Registros.Count());
        return respuesta;
    }

    public async Task<IEnumerable<RespuestaItemDto>> ObtenerItems(CancellationToken cancellationToken = default)
    {
        List<Item> items = (await _unitOfWork.Items.ObtenerTodosAsync(
            includeProperties: "MediaType,Format,Platform,ItemGenres.Genre,ItemCreators.Creator,ItemImages",
            cancellationToken)).ToList();
        
        _logger.LogInformation("Items paginados: {Count}", items.Count);
        return items.MapToDto();
    }

    public async Task<RespuestaItemDto> ObtenerItemPorId(Guid id, CancellationToken cancellationToken = default)
    {
        Item item = await ObtenerItem(id, track: false, cancellationToken);
        
        return item.MapToDto();
    }

    public async Task<RespuestaItemDto> AgregarItem(PeticionCrearItemDto itemDto, Guid currentUserId ,CancellationToken cancellationToken = default)
    {
        await ValidarReferenciasAsync(itemDto, cancellationToken);

        await _unitOfWork.BeginTransactionAsync();
        try
        {
            Item nuevoItem = itemDto.MapToEntity(currentUserId);

            foreach (Guid genreId in itemDto.GenreIds)
            {
                nuevoItem.ItemGenres?.Add(new ItemGenre { GenreId = genreId, ItemId = Guid.Empty });
            }

            Role? rolPorDefecto = await _unitOfWork.CreatorRoles.GetFirstOrDefaultAsync(
                r => r.Name == RoleConstants.Author, cancellationToken, disableTracking: true);
            Guid roleId = rolPorDefecto?.Id ?? Guid.Empty;

            foreach (Guid creatorId in itemDto.CreatorIds)
            {
                nuevoItem.ItemCreators?.Add(new ItemCreator { CreatorId = creatorId, ItemId = Guid.Empty, RoleId = roleId });
            }

            await _unitOfWork.Items.AgregarAsync(nuevoItem, cancellationToken);
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            _logger.LogInformation("Item agregado: {Id} - {Nombre}", nuevoItem.Id, nuevoItem.Title);

            ItemAgregadoEvento evento = nuevoItem.ToDto(currentUserId);

            await _serviceBus.NotificarAgregacionAsync(evento, cancellationToken);

            await _unitOfWork.CommitTransactionAsync(cancellationToken);

            return nuevoItem.MapToDto();
        }
        catch
        {
            await _unitOfWork.RollbackTransactionAsync(cancellationToken);
            throw;
        }
    }

    public async Task ActualizarItem(Guid id, PeticionActualizarItemDto itemDto, CancellationToken cancellationToken = default)
    {
        await ValidarReferenciasActualizarAsync(itemDto, cancellationToken);
        Item item = await ObtenerItem(id, track: true, cancellationToken);
        
        Role? rolPorDefecto = await _unitOfWork.CreatorRoles.GetFirstOrDefaultAsync(
            r => r.Name == RoleConstants.Author, cancellationToken, disableTracking: true);
        Guid defaultRoleId = rolPorDefecto?.Id ?? Guid.Empty;

        item.UpadteEntity(itemDto);
        SincronizarRelaciones(item, itemDto, defaultRoleId);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("Item actualizado: {Id} - {Nombre}", item.Id, item.Title);
    }

    public async Task EliminarItem(Guid id, CancellationToken cancellationToken = default)
    {
        Item item = await ObtenerItem(id, track: false, cancellationToken);
        
        _unitOfWork.Items.Eliminar(item);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        
        _logger.LogWarning("Item eliminado: {Id}", item.Id);
    }
    
    #region MetodosPrivados

    private async Task ValidarReferenciasAsync(PeticionCrearItemDto itemDto, CancellationToken cancellationToken)
    {
        bool mediaTypeExiste = await _unitOfWork.TiposMedia.GetFirstOrDefaultAsync(
            m => m.Id == itemDto.MediaTypeId, cancellationToken, disableTracking: true) is not null;
        if (!mediaTypeExiste)
        {
            throw new NotFoundException($"El tipo de medio {itemDto.MediaTypeId} no existe.");
        }

        bool formatoExiste = await _unitOfWork.Formatos.GetFirstOrDefaultAsync(
            f => f.Id == itemDto.FormatId, cancellationToken, disableTracking: true) is not null;
        if (!formatoExiste)
        {
            throw new NotFoundException($"El formato {itemDto.FormatId} no existe.");
        }

        if (itemDto.PlatformId.HasValue)
        {
            bool plataformaExiste = await _unitOfWork.Plataformas.GetFirstOrDefaultAsync(
                p => p.Id == itemDto.PlatformId.Value, cancellationToken, disableTracking: true) is not null;
            if (!plataformaExiste)
            {
                throw new NotFoundException($"La plataforma {itemDto.PlatformId.Value} no existe.");
            }
        }

        foreach (Guid genreId in itemDto.GenreIds)
        {
            bool generoExiste = await _unitOfWork.Generos.GetFirstOrDefaultAsync(
                g => g.Id == genreId, cancellationToken, disableTracking: true) is not null;
            if (!generoExiste)
            {
                throw new NotFoundException($"El género {genreId} no existe.");
            }
        }

        foreach (Guid creatorId in itemDto.CreatorIds)
        {
            bool creadorExiste = await _unitOfWork.Creadores.GetFirstOrDefaultAsync(
                c => c.Id == creatorId, cancellationToken, disableTracking: true) is not null;
            if (!creadorExiste)
            {
                throw new NotFoundException($"El creador {creatorId} no existe.");
            }
        }
    }

    private async Task ValidarReferenciasActualizarAsync(PeticionActualizarItemDto itemDto, CancellationToken cancellationToken)
    {
        bool mediaTypeExiste = await _unitOfWork.TiposMedia.GetFirstOrDefaultAsync(
            m => m.Id == itemDto.MediaTypeId, cancellationToken, disableTracking: true) is not null;
        if (!mediaTypeExiste)
        {
            throw new NotFoundException($"El tipo de medio {itemDto.MediaTypeId} no existe.");
        }

        bool formatoExiste = await _unitOfWork.Formatos.GetFirstOrDefaultAsync(
            f => f.Id == itemDto.FormatId, cancellationToken, disableTracking: true) is not null;
        if (!formatoExiste)
        {
            throw new NotFoundException($"El formato {itemDto.FormatId} no existe.");
        }

        if (itemDto.PlatformId.HasValue)
        {
            bool plataformaExiste = await _unitOfWork.Plataformas.GetFirstOrDefaultAsync(
                p => p.Id == itemDto.PlatformId.Value, cancellationToken, disableTracking: true) is not null;
            if (!plataformaExiste)
            {
                throw new NotFoundException($"La plataforma {itemDto.PlatformId.Value} no existe.");
            }
        }

        foreach (Guid genreId in itemDto.GenreIds)
        {
            bool generoExiste = await _unitOfWork.Generos.GetFirstOrDefaultAsync(
                g => g.Id == genreId, cancellationToken, disableTracking: true) is not null;
            if (!generoExiste)
            {
                throw new NotFoundException($"El género {genreId} no existe.");
            }
        }

        foreach (Guid creatorId in itemDto.CreatorIds)
        {
            bool creadorExiste = await _unitOfWork.Creadores.GetFirstOrDefaultAsync(
                c => c.Id == creatorId, cancellationToken, disableTracking: true) is not null;
            if (!creadorExiste)
            {
                throw new NotFoundException($"El creador {creatorId} no existe.");
            }
        }
    }

    private static void SincronizarRelaciones(Item item, PeticionActualizarItemDto itemDto, Guid defaultRoleId)
    {
        ICollection<ItemGenre> generos = item.ItemGenres!;
        ICollection<ItemCreator> creadores = item.ItemCreators!;

        List<Guid> generosActuales = generos.Select(g => g.GenreId).ToList();
        foreach (Guid genreId in itemDto.GenreIds.Where(id => !generosActuales.Contains(id)))
        {
            generos.Add(new ItemGenre { GenreId = genreId, ItemId = item.Id });
        }
        foreach (ItemGenre genero in generos.Where(g => !itemDto.GenreIds.Contains(g.GenreId)).ToList())
        {
            generos.Remove(genero);
        }

        List<Guid> creadoresActuales = creadores.Select(c => c.CreatorId).ToList();
        foreach (Guid creatorId in itemDto.CreatorIds.Where(id => !creadoresActuales.Contains(id)))
        {
            creadores.Add(new ItemCreator { CreatorId = creatorId, ItemId = item.Id, RoleId = defaultRoleId });
        }
        foreach (ItemCreator creador in creadores.Where(c => !itemDto.CreatorIds.Contains(c.CreatorId)).ToList())
        {
            creadores.Remove(creador);
        }
    }

    private async Task<Item> ObtenerItem(Guid id, bool track = true, CancellationToken cancellationToken = default)
    {
        Item? item = await _unitOfWork.Items.GetFirstOrDefaultAsync(
            predicate: i => i.Id == id,
            cancellationToken: cancellationToken,
            includeProperties: "MediaType,Format,Platform,ItemGenres.Genre,ItemCreators.Creator,ItemImages",
            disableTracking: !track
        );
        if (item == null)
        {
            _logger.LogWarning("No se encontro el item por el Id {id}", id);
            throw new NotFoundException($"No se encontro el item por el Id {id}");
        }
        return item;
    }

    #endregion
}